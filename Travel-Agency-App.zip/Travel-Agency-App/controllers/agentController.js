const Reservation = require('../models/Reservation');

// Get all reservations (for agents)
exports.getAllReservations = async (req, res) => {
    try {
        const reservations = await Reservation.find().populate('user package');
        res.json(reservations);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
