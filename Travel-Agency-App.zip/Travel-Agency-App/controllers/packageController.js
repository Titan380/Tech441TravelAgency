const Package = require('../models/Package');

// Get all vacation packages
exports.getAllPackages = async (req, res) => {
    try {
        const packages = await Package.find().populate('hotel airline');
        res.json(packages);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Create a new vacation package
exports.createPackage = async (req, res) => {
    const { name, description, price, city, hotel, airline, date } = req.body;
    try {
        const newPackage = new Package({
            name,
            description,
            price,
            city,
            hotel,
            airline,
            date
        });
        await newPackage.save();
        res.status(201).json(newPackage);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
