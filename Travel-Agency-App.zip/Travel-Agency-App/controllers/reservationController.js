const Reservation = require('../models/Reservation');

// Get all reservations for a user
exports.getReservations = async (req, res) => {
    try {
        console.log("Fetching reservations..."); // Log when this route is hit
        const reservations = await Reservation.find().populate('user package');
        console.log("Reservations found:", reservations); // Log the result
        res.json(reservations);
    } catch (err) {
        console.error("Error fetching reservations:", err); // Log the error
        res.status(500).json({ message: err.message });
    }
};

// Create a new reservation
exports.createReservation = async (req, res) => {
    try {
        const reservation = new Reservation({
            user: req.body.user,
            package: req.body.package,
            date: req.body.date
        });
        const savedReservation = await reservation.save();
        res.status(201).json(savedReservation);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};
