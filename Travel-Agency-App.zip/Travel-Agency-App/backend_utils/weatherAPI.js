const axios = require('axios');

const getWeather = async (city) => {
    try {
        const response = await axios.get(`https://api.weather.gov/gridpoints/${city}`);
        return response.data;
    } catch (err) {
        console.error('Weather API error:', err);
    }
};

module.exports = { getWeather };
