const mongoose = require('mongoose');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// Import the models
const Reservation = require('./backend_models/Reservation');
const User = require('./backend_models/User');
const Package = require('./backend_models/Package');

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('MongoDB connected for reservation creation'))
    .catch(err => console.error('MongoDB connection error:', err));

// Function to create a reservation
const createReservation = async () => {
    try {
        // Get a user and a package from the database
        const user = await User.findOne(); // Gets the first user
        const package = await Package.findOne(); // Gets the first package
        
        // Create a new reservation
        const newReservation = new Reservation({
            user: user._id,
            package: package._id,
            date: new Date()
        });

        await newReservation.save();
        console.log('Reservation created:', newReservation);
        
        mongoose.connection.close(); // Close the connection after saving
    } catch (err) {
        console.error('Error creating reservation:', err);
        mongoose.connection.close();
    }
};

// Run the function to create a reservation
createReservation();
