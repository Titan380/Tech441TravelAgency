const express = require('express');
const { getAllPackages, createPackage } = require('../controllers/packageController');
const router = express.Router();

router.get('/', getAllPackages);
router.post('/', createPackage);

module.exports = router;
