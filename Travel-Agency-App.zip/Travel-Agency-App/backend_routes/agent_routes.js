const express = require('express');
const { getAllReservations } = require('../controllers/agentController');
const router = express.Router();

router.get('/reservations', getAllReservations);

module.exports = router;
