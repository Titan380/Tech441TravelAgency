const mongoose = require('mongoose');

const packageSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String },
    price: { type: Number, required: true },
    city: { type: String, required: true },
    hotel: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel' },
    airline: { type: mongoose.Schema.Types.ObjectId, ref: 'Airline' },
    date: { type: Date, required: true }
});

module.exports = mongoose.model('Package', packageSchema);
